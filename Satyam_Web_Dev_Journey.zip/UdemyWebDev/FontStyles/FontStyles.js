 var plus = document.getElementById("FontIncrease");

        var minus = document.getElementById("FontDecrease");

        var para = document.getElementById('fontstyle');

        var font_size = window.getComputedStyle(para).fontSize;

       

        var actualnumber = parseInt(font_size.substr(0,font_size.length-2));

        plus.addEventListener("click",function(){
            actualnumber += 10;
            para.style.fontSize = actualnumber + "px";
        })
        minus.addEventListener("click",function(){
            actualnumber -= 10;
            para.style.fontSize = actualnumber + "px";
        })
