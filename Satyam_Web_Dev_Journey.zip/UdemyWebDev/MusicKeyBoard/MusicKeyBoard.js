
      var keydrum = document.getElementsByClassName("keydrum");

      document.body.addEventListener("keydown", function (event) {
        var key = event.keyCode; //remember no paranthesis.
        if (key == 65) {
          console.log("key A is pressed.");
          document.getElementById("drumkey1").classList.add("spotlight");
          document.getElementById("drumkey1").style.borderColor = "yellow";
          var key1 = document.getElementById("drumkey1");
          let sound1 = key1.getAttribute("data-sound");
          key1.audio = new Audio(sound1);
          key1.audio.play();
        } else if (key == 83) {
          console.log("key S is pressed.");
          document.getElementById("drumkey2").classList.add("spotlight");
          document.getElementById("drumkey2").style.borderColor = "yellow";
          var key2 = document.getElementById("drumkey2");
          let sound2 = key2.getAttribute("data-sound");
          key2.audio = new Audio(sound2);
          key2.audio.play();
        } else if (key == 68) {
          console.log("key D is pressed.");
          document.getElementById("drumkey3").classList.add("spotlight");
          document.getElementById("drumkey3").style.borderColor = "yellow";
          var key3 = document.getElementById("drumkey3");
          let sound3 = key3.getAttribute("data-sound");
          key3.audio = new Audio(sound3);
          key3.audio.play();
        } else if (key == 70) {
          console.log("key F is pressed.");
          document.getElementById("drumkey4").classList.add("spotlight");
          document.getElementById("drumkey4").style.borderColor = "yellow";
          var key4 = document.getElementById("drumkey4");
          let sound4 = key4.getAttribute("data-sound");
          key4.audio = new Audio(sound4);
          key4.audio.play();
        } else if (key == 71) {
          console.log("key G is pressed.");
          document.getElementById("drumkey5").classList.add("spotlight");
          document.getElementById("drumkey5").style.borderColor = "yellow";
          var key5 = document.getElementById("drumkey5");
          var sound5 = key5.getAttribute("data-sound");
          key5.audio = new Audio(sound5);
          key5.audio.play();
        } else if (key == 72) {
          console.log("key H is pressed.");
          document.getElementById("drumkey6").classList.add("spotlight");
          document.getElementById("drumkey6").style.borderColor = "yellow";
          var key6 = document.getElementById("drumkey6");
          let sound6 = key6.getAttribute("data-sound");
          key6.audio = new Audio(sound6);
          key6.audio.play();
        } else if (key == 74) {
          console.log("key J is pressed.");
          document.getElementById("drumkey7").classList.add("spotlight");
          document.getElementById("drumkey7").style.borderColor = "yellow";
          var key7 = document.getElementById("drumkey7");
          let sound7 = key7.getAttribute("data-sound");
          key7.audio = new Audio(sound7);
          key7.audio.play();
        } else if (key == 75) {
          console.log("key K is pressed.");
          document.getElementById("drumkey8").classList.add("spotlight");
          document.getElementById("drumkey8").style.borderColor = "yellow";
          var key8 = document.getElementById("drumkey8");
          let sound8 = key8.getAttribute("data-sound");
          key8.audio = new Audio(sound8);
          key8.audio.play();
        } else if (key == 76) {
          console.log("key L is pressed.");
          document.getElementById("drumkey9").classList.add("spotlight");
          document.getElementById("drumkey9").style.borderColor = "yellow";
          var key9 = document.getElementById("drumkey9");
          let sound9 = key9.getAttribute("data-sound");
          key9.audio = new Audio(sound9);
          key9.audio.play();
        }
      });

      const sound = document.getElementById("audio");

      document.body.addEventListener("keyup", function (event) {
        var key = event.keyCode; //remember no paranthesis.
        if (key == 65) {
          console.log("key A is pressed.");
          document.getElementById("drumkey1").classList.remove("spotlight");
        } else if (key == 83) {
          console.log("key S is pressed.");
          document.getElementById("drumkey2").classList.remove("spotlight");
        } else if (key == 68) {
          console.log("key D is pressed.");
          document.getElementById("drumkey3").classList.remove("spotlight");
        } else if (key == 70) {
          console.log("key F is pressed.");
          document.getElementById("drumkey4").classList.remove("spotlight");
        } else if (key == 71) {
          console.log("key G is pressed.");
          document.getElementById("drumkey5").classList.remove("spotlight");
        } else if (key == 72) {
          console.log("key H is pressed.");
          document.getElementById("drumkey6").classList.remove("spotlight");
        } else if (key == 74) {
          console.log("key J is pressed.");
          document.getElementById("drumkey7").classList.remove("spotlight");
        } else if (key == 75) {
          console.log("key K is pressed.");
          document.getElementById("drumkey8").classList.remove("spotlight");
        } else if (key == 76) {
          console.log("key L is pressed.");
          document.getElementById("drumkey9").classList.remove("spotlight");
        }

        var key = document.getElementsByClassName("key");
        for (let i = 0; i < key.length; i++) {
          key[i].style.borderColor = "black";
        }
      });
    