 var para = document.getElementById("para");
        var paratext = para.innerHTML;
        
        var sourceImage = document.getElementById("image");

      var interval =   setInterval(() => {
          paratext = paratext > 0 ? paratext - 1 : 0;
          para.innerHTML = paratext;
          var image = paratext%2 == 0 ? "https://img.freepik.com/free-vector/abstract-low-poly-design_1048-6847.jpg?semt=ais_hybrid&w=740&q=80":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFUtDaJ6nxmzoxtoJQxzoNTG_T6HmM70MerA&s";
          
          sourceImage.src = image;

          sourceImage.className = "backImage";
          console.log(sourceImage);
          if(paratext == 0){
            clearInterval(interval);
          }

        }, 1000);