 var input = document.getElementById("input");
      var btn = document.getElementById("btn");
      var list = document.getElementById("list-items");
      var updating = document.getElementById("btn1");
      var deleting = document.getElementById("btn2");
      var icon = document.getElementsByClassName("delete-icon");
      

    //  $(document).ready(function(){
    //    $('i').click(function(){
    //     $(this).parent().remove();
    //    })
    //  })

    //  $("btn2").click(function(){
    //   console.log($('ul.first').children());
    //  })

      
      
      
     
      

      // var textNode = "";

      

      // input.addEventListener("input", function (e) {
      //   textNode = e.target.value;
      // });

      function AddToDoItem(){
        const value = input.value.trim();
      }

      input.addEventListener("keyup", function (e) {
        if (e.key == "Enter") {
          AddToDoItem(); //e.keyCode === 13 outdated.
        }
      });

      updating.addEventListener("click", updateFirstElement);

      deleting.addEventListener("click", function () {
        let first = list.firstElementChild;
        if (first) {
          list.removeChild(first);
        } else {
          alert("No task to delete");
        }
      });

      btn.addEventListener("click", AddToDoItem);

      function AddToDoItem() {
        if (textNode.trim() !== "") {
          //   textNode !== undefined && textNode !== null && textNode !== "" out dated ho gaya.
          var newElement = document.createElement("li");
          newElement.classList.add("item");

          var span = document.createElement("span");
          
          span.textContent = textNode;
          span.classList.add("task");

          //   var inner = document.createTextNode(textNode);
          //   var element = newElement.appendChild(inner);
          var icon = document.createElement("i");
          icon.classList.add("fa-solid", "fa-trash", "delete-icon");

          icon.addEventListener("click", function (e) {
            // newElement.remove();
            // e.target.parentElement.remove();
            this.parentElement.remove();

          });

          newElement.appendChild(span);
          newElement.appendChild(icon);
          list.appendChild(newElement);

          textNode = "";
          input.value = "";
        } else {
          alert("Please enter valid task");
        }
      }

      function updateFirstElement() {
        if (textNode) {
          let first = list.firstElementChild;
          
          if (first) {
            first.querySelector(".task").textContent = textNode;
           
            textNode = "";
            input.value = "";
          }
        } else {
          alert("Please enter valid task or enter a task to update the task.");
        }
      }
      

