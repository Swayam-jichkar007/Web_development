const input = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const updateBtn = document.getElementById("updateBtn");
const deleteBtn = document.getElementById("deleteBtn");
const list = document.getElementById("taskList");

/* ADD TASK */
addBtn.addEventListener("click", addTask);

input.addEventListener("keyup", function(e){
  if(e.key === "Enter"){
    addTask();
  }
});

function addTask(){
  const value = input.value.trim();

  if(value === ""){
    alert("Please enter a task");
    return;
  }

  const li = document.createElement("li");
  li.className = "item";

  const span = document.createElement("span");
  span.className = "task";
  span.textContent = value;

  const icon = document.createElement("i");
  icon.className = "fa-solid fa-trash delete-icon";

  icon.addEventListener("click", function(){
    li.remove();
  });

  li.appendChild(span);
  li.appendChild(icon);
  list.appendChild(li);

  input.value = "";
}

/* UPDATE FIRST TASK */
updateBtn.addEventListener("click", function () {
  const value = input.value.trim();

  if (list.children.length === 0) {
    alert("No task to update");
    return;
  }

  if (value === "") {
    alert("Type new text in input to update first task");
    return;
  }

  const firstTask = list.children[0].querySelector(".task");
  firstTask.textContent = value;

  input.value = "";
});



/* DELETE FIRST TASK */
deleteBtn.addEventListener("click", function(){
  const first = list.firstElementChild;

  if(first){
    first.remove();
  }else{
    alert("No task to delete");
  }
});
