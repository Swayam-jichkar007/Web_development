const black = document.getElementById("black");
const red = document.getElementById("red");
const grey = document.getElementById("grey");
const brown = document.getElementById("brown");
const pink = document.getElementById("pink");
const img = document.getElementById("watchimg");
const time = document.getElementById("time");
const para = document.getElementById("watchpara");
const rate = document.getElementById("heartrate");
// const bolt = document.getElementsByTagName("b");

red.addEventListener("click",function(){
    let imgchange = img.setAttribute("src","redwatch.png");

})
black.addEventListener("click",function(){
    let imgchange = img.setAttribute("src","BlackWatch.png");

})
grey.addEventListener("click",function(){
    let imgchange = img.setAttribute("src","Bluewatch.png");

})
pink.addEventListener("click",function(){
    let imgchange = img.setAttribute("src","pinkwatch.png");

})
brown.addEventListener("click",function(){
    let imgchange = img.setAttribute("src","purplewatch.png");

})

let timeInterval = null;

time.addEventListener("click",function(){
    clearInterval(timeInterval); //purana time interval off karne ke liye.
  function showtime(){
    let now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();
    //padstart(totalength,fillcharacter)
    //agar character ki length 2 se chhoti hogi toh \
    //0 add ho jayega start mein.
    hours = hours.toString().padStart(2,'0');
    minutes = minutes.toString().padStart(2,'0');
    seconds = seconds.toString().padStart(2,'0');

    para.innerHTML = `<h4><b>${hours} : ${minutes} : ${seconds}<b></h4>`;
    
  }
  showtime(); //immediate start karne ke liye....

   timeInterval = setInterval(showtime,1000);
});
//heart and uske rate ke liye....
rate.addEventListener('click',function(){
    // const span1 = document.createElement("span");
    // const span2 = document.createElement("span");
    // span1.innerText = `❤`;
    // span2.innerText = `78`;
    // span1.classList.add("hearts");
    // span2.classList.add("rates");
   
    // para.appendChild(span1);
    // para.appendChild(span2);
    clearInterval(timeInterval); //to stop time
    para.innerHTML = `<span class="hearts">❤</span><br>
    <span class="rate">78</span>`;
   
    
    
});

