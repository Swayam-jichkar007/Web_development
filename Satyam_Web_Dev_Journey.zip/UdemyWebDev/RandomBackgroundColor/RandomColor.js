
        var btn = document.getElementById("btn");
        var back = document.querySelector("body");
       
        //btn.onclick = btnclicked(); //paranthesis use kiya toh automatically pehle call ho jayega.

        btn.onclick = btnclicked;

         function btnclicked(){
            // console.log(Math.floor(Math.random() * 255));
            // alert("button clicked!");
            // btn.style.backgroundColor = "cyan";
            // btn.style.color = "red";
            back.style.backgroundColor = "rgb(" + Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+")";
            // alert("rgb(" + Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+")");
            
        }

        // btn.addEventListener('click',function(){
        //     alert("button is clicked...");
        // })

        //btn.addEventListener("click",btnclicked); //bro don't use paranthesis.
    