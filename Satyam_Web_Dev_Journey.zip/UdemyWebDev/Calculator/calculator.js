// script.js

let result = document.getElementById("result");

function appendValue(value) {
    result.value += value;  // Add the clicked button value to input
}

function clearResult() {
    result.value = "";  // Clear the input
}

function calculateResult() {
    if(result.value === "") return; // If empty, do nothing
    try {
        result.value = eval(result.value);  // Evaluate the expression
    } catch (error) {
        result.value = "Error";  // If invalid input, show Error
    }
}
